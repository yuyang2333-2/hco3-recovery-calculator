const fs=require('fs');
const src=fs.readFileSync('model_js.js','utf8');
const {META_BASE,TREES}=new Function(src+';return {META_BASE,TREES};')();
function pred(x){
  let s=Math.log(META_BASE/(1-META_BASE));
  for(const t of TREES){
    let i=0;
    while(t.l[i]!==-1){
      const f=t.f[i];
      i = (x[f] < t.t[i]) ? t.l[i] : t.r[i];
    }
    s+=t.v[i];
  }
  return 1/(1+Math.exp(-s));
}
const lines=fs.readFileSync('ref_pred.csv','utf8').trim().split(/\r?\n/);
const hdr=lines[0].split(',');
const fea=hdr.slice(0,-1);
let maxd=0,worst=null;
for(const ln of lines.slice(1)){
  const v=ln.split(',').map(Number);
  const x=v.slice(0,-1); const ref=v[v.length-1];
  const p=pred(x); const d=Math.abs(p-ref);
  if(d>maxd){maxd=d;worst=[ref,p];}
}
console.log('n',lines.length-1,'max abs diff',maxd.toExponential(3),'worst',worst);
