Bicarbonate Recovery Failure Calculator
Model object, browser page and reference predictions

Version 1.0
Released 8 November 2026


--------------------------------------------------------------------------------
WHAT THIS IS
--------------------------------------------------------------------------------

A self-contained browser page that estimates the probability that a septic
patient admitted with a high anion gap will fail to recover a bicarbonate of
22 mmol/L or above by 24-48 h after ICU admission.

It accompanies the manuscript:

  Discordance between anion gap load and bicarbonate recovery in sepsis:
  a four-database cohort study with a 12-hour prediction tool

The page carries the fitted gradient-boosted model itself. It therefore runs
offline, with no server, no installation and no network connection, and the
probability it displays is computed from the same 310 trees as the analysis
object rather than from a re-implemented approximation.


--------------------------------------------------------------------------------
FILES
--------------------------------------------------------------------------------

  index.html        The calculator. Open it in any current browser.
  about.html        Methods page: eligibility, predictor encoding, cohorts,
                    performance, verification steps and limitations.
  404.html          Not-found page, used when the pair is served as a site.
  model.json        The fitted XGBoost booster (310 trees), native JSON format.
  model_js.js       The same booster exported as plain JavaScript trees. This
                    is what index.html evaluates.
  model_meta.json   Feature order, imputation medians, development-cohort
                    tertiles and per-database performance.
  ref_pred.csv      60 feature vectors with the reference probability for each,
                    for independent verification.
  t_check.js        Node.js script that recomputes ref_pred.csv from
                    model_js.js and reports the maximum absolute difference.
  LICENSE           CC BY 4.0.
  README.txt        This file.


--------------------------------------------------------------------------------
HOW TO USE
--------------------------------------------------------------------------------

Open index.html in a browser and enter seven values. Nothing is uploaded;
all arithmetic is local.

The right-hand card has three tabs.

  Prediction          The probability, the risk band and the band-specific
                      observed failure rate.
  Numerical summary   Every prediction made in the session, one row each,
                      downloadable as CSV. Rows are held in the browser only
                      and are not transmitted.
  Model performance   Model specification and the per-database performance
                      table.

A methods page, about.html, records how the model was built, how to verify a
prediction and what the model does not do.

  Age              years
  Sex              male / female
  SOFA score       points, first 24 h
  Anion gap        first value, mmol/L
  Bicarbonate      first value, mmol/L
  Lactate          maximum over 0-12 h, mmol/L
  Creatinine       maximum over 0-12 h, mg/dL


--------------------------------------------------------------------------------
INTERNAL ENCODING
--------------------------------------------------------------------------------

The seven inputs map onto nine model features, in this order:

  age, male, sev_z, ag12, bi0, lac12, cr12, lac_miss, cr_miss

  male      = 1 if male, 0 if female
  sev_z     = (SOFA - 4.0638) / 2.243
  ag12      = anion gap, first value
  bi0       = bicarbonate, first value
  lac12     = lactate, maximum over 0-12 h
  cr12      = creatinine, maximum over 0-12 h
  lac_miss  = 1 if lactate missing, else 0;    lac12 then set to 2.4
  cr_miss   = 1 if creatinine missing, else 0; cr12  then set to 1.45

Missing lactate and creatinine are replaced by the development-cohort median
and flagged by the indicator, the same handling used during training. The
page states on screen when a substitution has been made.


--------------------------------------------------------------------------------
OUTPUT
--------------------------------------------------------------------------------

A probability of failure to recover, and a band.

The cut-points 0.53 and 0.77 are tertiles of predicted probability in the
development cohort, where observed failure to recover was 37.5%, 64.6% and
89.0% across the three bands. A band therefore describes where a patient sits
relative to the rest of the cohort. It is not an absolute risk, and it does
not define a treatment threshold.


--------------------------------------------------------------------------------
SCOPE GUARDS
--------------------------------------------------------------------------------

  Bicarbonate >= 22 mmol/L   the page states that the patient lies outside the
                             scope of the model and returns no estimate
  Anion gap < 20 mmol/L      the estimate is flagged as an extrapolation

Neither guard is silent.


--------------------------------------------------------------------------------
MODEL PERFORMANCE
--------------------------------------------------------------------------------

  Cohort      n       Events   Prevalence   AUC (95% CI)         Brier
  MIMIC-IV    10,304   6,567    63.7%       0.780 (0.771-0.789)  0.181
  eICU-CRD     3,602   2,193    60.9%       0.683 (0.666-0.701)  0.220
  SICdb        3,821   1,491    39.0%       0.731 (0.715-0.747)  0.206
  NWICU        5,864   2,978    50.8%       0.719 (0.706-0.732)  0.229

Discrimination is transported across databases better than absolute risk.
Recalibrate locally before any clinical use.


--------------------------------------------------------------------------------
REPRODUCING A PREDICTION FROM model.json
--------------------------------------------------------------------------------

R:

  library(xgboost)
  b <- xgb.load("model.json")
  x <- matrix(c(age, male, sev_z, ag12, bi0, lac12, cr12, lac_miss, cr_miss),
              nrow = 1)
  predict(b, x)

Python:

  import xgboost as xgb, numpy as np
  b = xgb.Booster(); b.load_model("model.json")
  x = np.array([[age, male, sev_z, ag12, bi0, lac12, cr12, lac_miss, cr_miss]])
  b.predict(xgb.DMatrix(x, feature_names=[...]))

The booster carries the feature names listed above, so passing them explicitly
is optional but recommended. Column order must match exactly. The objective is
binary:logistic, so both predict calls return a probability, not a margin.


--------------------------------------------------------------------------------
VERIFYING THE PAGE
--------------------------------------------------------------------------------

  node t_check.js
  -> n 60 max abs diff 6.246e-7

Loading model.json directly with XGBoost 3.4.1 and predicting the same 60 rows
gives a maximum absolute difference of 4.977e-7 against ref_pred.csv.

The browser page, the exported JavaScript trees and the fitted model object
therefore agree to within 1 x 10^-6, as stated in the manuscript. The reference
values in ref_pred.csv were produced by the analysis object, not by the page.


--------------------------------------------------------------------------------
LICENSE
--------------------------------------------------------------------------------

Creative Commons Attribution 4.0 International (CC BY 4.0).

The model is derived from four public critical care databases (MIMIC-IV,
eICU-CRD, SICdb, NWICU) obtained under their respective data use agreements.
No individual-level patient data are redistributed in this archive.


--------------------------------------------------------------------------------
CITATION
--------------------------------------------------------------------------------

Cite the manuscript above together with this record and its DOI.


--------------------------------------------------------------------------------
CONTACT
--------------------------------------------------------------------------------

Corresponding author: <name, affiliation, e-mail>
